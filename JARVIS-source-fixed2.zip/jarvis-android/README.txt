JARVIS Android - build: push this folder to a GitHub repo; Actions > "Build JARVIS APK" > download jarvis-apk. Or open in Android Studio.
Setup in app: 1 save API key  2 permissions  3 Accessibility ON  4 overlay ON (lets it open apps from background)  then START JARVIS.
Say: "Jarvis, open YouTube" / "Jarvis, call Mom" (say allow) / "Jarvis, open CapCut, create a new project, add my latest clips, edit it formal, export".
Say "stop" to halt the agent. Never share your API key.
Memory: say "Jarvis, remember ..." - saved permanently (encrypted) and used in every command. "Jarvis, forget everything" clears it.
Spotify: "Jarvis, go Spotify play <song>", then "Jarvis, play next".
Claude: "Jarvis, open Claude and build me <idea>" - JARVIS writes the prompt and sends it.
