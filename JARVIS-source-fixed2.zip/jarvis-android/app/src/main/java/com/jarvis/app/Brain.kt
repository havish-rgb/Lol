package com.jarvis.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class BrainException(message: String) : Exception(message)

object Prefs {
    @Volatile private var cached: SharedPreferences? = null

    @Synchronized
    fun get(context: Context): SharedPreferences {
        cached?.let { return it }
        val app = context.applicationContext
        val prefs: SharedPreferences = try {
            val alias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            EncryptedSharedPreferences.create(
                "jarvis_secure",
                alias,
                app,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Keystore problem on some phones: fall back so the app never crashes.
            app.getSharedPreferences("jarvis_plain", Context.MODE_PRIVATE)
        }
        cached = prefs
        return prefs
    }
}

object Brain {
    private const val DEFAULT_URL = "https://openrouter.ai/api/v1/chat/completions"
    private const val DEFAULT_MODEL = "anthropic/claude-sonnet-4.5"

    fun ask(context: Context, system: String, user: String): String {
        val prefs = Prefs.get(context)
        val apiKey = prefs.getString("key", "").orEmpty().trim()
        if (apiKey.isBlank()) throw BrainException("Please add your API key in the app first, sir.")
        val model = prefs.getString("model", "").orEmpty().trim().ifBlank { DEFAULT_MODEL }
        val endpoint = prefs.getString("endpoint", "").orEmpty().trim().ifBlank { DEFAULT_URL }

        val body = JSONObject()
            .put("model", model)
            .put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user))
            )

        val connection: HttpURLConnection = try {
            URL(endpoint).openConnection() as HttpURLConnection
        } catch (e: Exception) {
            throw BrainException("The brain address looks wrong, sir.")
        }

        try {
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.connectTimeout = 20000
            connection.readTimeout = 60000
            connection.setRequestProperty("Authorization", "Bearer $apiKey")
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                val msg = when (code) {
                    401, 403 -> "My brain rejected the API key, sir."
                    402 -> "The API account is out of credit, sir."
                    404 -> "That model or address wasn't found, sir."
                    429 -> "Too many requests, sir. Give me a moment."
                    else -> "The brain returned error $code, sir."
                }
                throw BrainException(msg)
            }
            return JSONObject(text)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        } catch (e: BrainException) {
            throw e
        } catch (e: IOException) {
            throw BrainException("I have no internet connection to my brain, sir.")
        } catch (e: Exception) {
            throw BrainException("My brain gave an answer I couldn't read, sir.")
        } finally {
            connection.disconnect()
        }
    }

    fun json(value: String): JSONObject {
        val start = value.indexOf('{')
        val end = value.lastIndexOf('}')
        if (start < 0 || end <= start) throw BrainException("My brain didn't answer in the right format, sir.")
        try {
            return JSONObject(value.substring(start, end + 1))
        } catch (e: Exception) {
            throw BrainException("My brain didn't answer in the right format, sir.")
        }
    }
}

object Memory {
    fun all(context: Context): String = Prefs.get(context).getString("mem", "").orEmpty()

    fun add(context: Context, fact: String) {
        val updated = (all(context) + "\n- " + fact).takeLast(8000)
        Prefs.get(context).edit().putString("mem", updated).apply()
    }

    fun clear(context: Context) {
        Prefs.get(context).edit().remove("mem").apply()
    }
}
