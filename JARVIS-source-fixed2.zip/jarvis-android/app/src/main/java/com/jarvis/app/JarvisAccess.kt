package com.jarvis.app
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccess : AccessibilityService() {
  companion object { var I: JarvisAccess? = null }
  override fun onServiceConnected() { I = this }
  override fun onUnbind(i: android.content.Intent?): Boolean { I = null; return super.onUnbind(i) }
  override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
  override fun onInterrupt() {}

  fun dump(): String { val sb = StringBuilder(); walk(rootInActiveWindow, sb); return sb.toString().take(7000) }
  private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder) {
    if (n == null) return
    val t = (n.text ?: n.contentDescription)?.toString()
    val r = Rect(); n.getBoundsInScreen(r)
    if (!t.isNullOrBlank()) sb.append(if (n.isClickable) "[click] " else "").append(t).append('\n')
    else if (n.isClickable) sb.append("[icon at ${r.centerX()},${r.centerY()}]\n")
    for (i in 0 until n.childCount) walk(n.getChild(i), sb)
  }
  fun click(t: String): Boolean {
    val n = rootInActiveWindow?.findAccessibilityNodeInfosByText(t)?.firstOrNull() ?: return false
    var c: AccessibilityNodeInfo? = n
    while (c != null && !c.isClickable) c = c.parent
    if (c != null) return c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    val r = Rect(); n.getBoundsInScreen(r); tap(r.centerX(), r.centerY()); return true
  }
  fun tap(x: Int, y: Int) {
    val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
    dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
  }
  fun type(t: String) {
    val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
    f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) })
  }
  fun scroll() { find(rootInActiveWindow)?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) }
  private fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
    if (n == null) return null; if (n.isScrollable) return n
    for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }; return null
  }
  fun back() { performGlobalAction(GLOBAL_ACTION_BACK) }
}
